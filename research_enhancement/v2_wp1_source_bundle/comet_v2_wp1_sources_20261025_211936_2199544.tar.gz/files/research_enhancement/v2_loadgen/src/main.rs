mod accounting;
mod dispatcher;
mod http_client;
mod http_dispatcher;
mod inference_protocol;
mod jsonl_output;
mod noop_dispatcher;
mod request_record;
mod run_summary;
mod schedule;
mod timing;

use anyhow::{bail, Context, Result};
use serde::Deserialize;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::env;
use std::fs;

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Trace {
    schema_version: String,
    model: String,
    dataset: String,
    seed: i64,
    request_count: usize,
    tenant_count: usize,
    golden_model_sha256: String,
    golden_dataset_sha256: String,
    golden_artifact_sha256: String,
    requests: Vec<TraceRequest>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
struct TraceRequest {
    request_id: String,
    sequence: usize,
    tenant_slot: usize,
    model: String,
    source_row_index: usize,
    features: Vec<f64>,
    expected_prediction: i64,
    ground_truth_label: i64,
}

fn validate(trace: &Trace) -> Result<()> {
    if trace.schema_version != "comet-v2-trace-v1" {
        bail!("Unsupported trace schema");
    }

    if trace.model != "lr" {
        bail!("Only LR traces are currently supported");
    }

    if trace.dataset != "iris_binary" {
        bail!("Unexpected dataset");
    }

    if trace.request_count == 0 || trace.request_count != trace.requests.len() {
        bail!("Invalid request count");
    }

    if trace.tenant_count == 0 {
        bail!("Tenant count must be positive");
    }

    for (name, digest) in [
        ("model", &trace.golden_model_sha256),
        ("dataset", &trace.golden_dataset_sha256),
        ("golden artifact", &trace.golden_artifact_sha256),
    ] {
        if digest.len() != 64 || !digest.bytes().all(|b| b.is_ascii_hexdigit()) {
            bail!("Invalid {name} SHA-256 field");
        }
    }

    let mut request_ids = HashSet::new();

    for (index, request) in trace.requests.iter().enumerate() {
        if request.sequence != index {
            bail!("Invalid sequence at request {index}");
        }

        if request.request_id != format!("v2-{index:08}") {
            bail!("Unexpected request ID at index {index}");
        }

        if !request_ids.insert(&request.request_id) {
            bail!("Duplicate request ID");
        }

        if request.tenant_slot >= trace.tenant_count {
            bail!("Tenant slot out of range");
        }

        if request.model != trace.model {
            bail!("Request model mismatch");
        }

        if request.features.len() != 4 || !request.features.iter().all(|x| x.is_finite()) {
            bail!("Invalid LR feature vector");
        }

        if !matches!(request.expected_prediction, 0 | 1) {
            bail!("Invalid expected prediction");
        }

        if !matches!(request.ground_truth_label, 0 | 1) {
            bail!("Invalid ground-truth label");
        }

        if request.source_row_index >= 45 {
            bail!("Source row index out of range");
        }
    }

    Ok(())
}

fn verify_golden(trace: &Trace, golden_path: &str) -> Result<()> {
    let bytes = fs::read(golden_path)
        .with_context(|| format!("Cannot read golden reference: {golden_path}"))?;

    let digest = format!("{:x}", Sha256::digest(&bytes));

    if digest != trace.golden_artifact_sha256 {
        bail!("Golden reference SHA-256 mismatch");
    }

    let golden: Value = serde_json::from_slice(&bytes).context("Invalid golden reference JSON")?;

    if golden["schema_version"] != "comet-v2-golden-v1"
        || golden["model"] != trace.model
        || golden["dataset"] != trace.dataset
        || golden["model_sha256"] != trace.golden_model_sha256
        || golden["dataset_sha256"] != trace.golden_dataset_sha256
    {
        bail!("Golden reference metadata mismatch");
    }

    let records = golden["records"]
        .as_array()
        .context("Golden reference records missing")?;

    if golden["sample_count"].as_u64() != Some(records.len() as u64) {
        bail!("Golden reference sample count mismatch");
    }

    let mut source_rows = std::collections::HashMap::new();

    for record in records {
        let index = record["row_index"]
            .as_u64()
            .context("Invalid golden source row index")?;

        if source_rows.insert(index, record).is_some() {
            bail!("Duplicate golden source row index");
        }
    }

    for request in &trace.requests {
        let source = source_rows
            .get(&(request.source_row_index as u64))
            .context("Trace references unknown source row")?;

        let features: Vec<f64> = serde_json::from_value(source["features"].clone())
            .context("Invalid golden features")?;

        if features != request.features
            || source["expected_prediction"].as_i64() != Some(request.expected_prediction)
            || source["ground_truth_label"].as_i64() != Some(request.ground_truth_label)
        {
            bail!(
                "Golden reference mismatch at request {}",
                request.request_id
            );
        }
    }

    Ok(())
}

fn run_http_mode(trace: &Trace, args: &[String]) -> Result<()> {
    use std::path::Path;
    use std::time::Duration;

    use hyper::Uri;

    if args.len() != 10 {
        bail!(
            "Usage: comet_v2_loadgen <trace.json> <golden.json> http \
             <endpoint> <backend> <rps> <timeout_ms> <max_inflight> <output_prefix>"
        );
    }

    let uri: Uri = args[4].parse().context("Invalid HTTP endpoint")?;

    if uri.scheme_str() != Some("http") || uri.host().is_none() || uri.path() != "/infer" {
        bail!("Endpoint must be an HTTP URL ending in /infer");
    }

    let backend = &args[5];

    if backend.trim().is_empty() {
        bail!("Backend must not be empty");
    }

    let offered_rps: f64 = args[6].parse().context("Invalid offered RPS")?;
    schedule::scheduled_offset(0, offered_rps)?;

    let timeout_ms: u64 = args[7].parse().context("Invalid timeout")?;
    if timeout_ms == 0 {
        bail!("Timeout must be positive");
    }

    let max_inflight: usize = args[8].parse().context("Invalid max_inflight")?;
    if max_inflight == 0 {
        bail!("max_inflight must be positive");
    }

    let prefix = Path::new(&args[9]);

    let jsonl_path = prefix.with_extension("requests.jsonl");
    let summary_path = prefix.with_extension("summary.json");

    if jsonl_path.exists() || summary_path.exists() {
        bail!("Experiment output already exists; refusing to overwrite");
    }

    let client = http_client::HttpClient::new(Duration::from_millis(timeout_ms))?;

    let worker_count: usize = std::env::var("COMET_LOADGEN_WORKERS")
        .unwrap_or_else(|_| "2".to_string())
        .parse()
        .context("COMET_LOADGEN_WORKERS must be a positive integer")?;

    if worker_count == 0 {
        bail!("COMET_LOADGEN_WORKERS must be greater than zero");
    }

    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(worker_count)
        .enable_all()
        .build()?;

    println!("Load-generator Tokio workers: {}", worker_count);

    println!("HTTP MODE");
    println!("Endpoint: {}", uri);
    println!("Expected backend: {}", backend);
    println!("Offered RPS: {}", offered_rps);
    println!("Timeout (ms): {}", timeout_ms);
    println!("Max in-flight: {}", max_inflight);
    println!("Offered requests: {}", trace.requests.len());

    let records = runtime.block_on(http_dispatcher::dispatch_http(
        &trace.requests,
        offered_rps,
        uri,
        backend,
        client,
        max_inflight,
    ))?;

    let summary = run_summary::summarize(&records);

    jsonl_output::write_jsonl(&jsonl_path, &records)?;

    let summary_json = serde_json::to_vec_pretty(&summary)?;

    let mut summary_file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&summary_path)
        .with_context(|| format!("Cannot create {}", summary_path.display()))?;

    use std::io::Write;
    summary_file.write_all(&summary_json)?;
    summary_file.sync_all()?;

    println!("Successful requests: {}", summary.successful_requests);
    println!("Failed requests: {}", summary.failed_requests);
    println!("Timed out requests: {}", summary.timed_out_requests);
    println!("Dropped requests: {}", summary.dropped_requests);
    println!("P50 latency (ms): {:?}", summary.p50_latency_ms);
    println!("P95 latency (ms): {:?}", summary.p95_latency_ms);
    println!("P99 latency (ms): {:?}", summary.p99_latency_ms);
    println!("Requests JSONL: {}", jsonl_path.display());
    println!("Summary JSON: {}", summary_path.display());

    Ok(())
}

fn run_noop_mode(args: &[String]) -> Result<()> {
    use hyper::Uri;
    use std::{io::Write, path::Path, time::Duration};
    if args.len() != 8 {
        bail!("Usage: comet_v2_loadgen noop <http://127.0.0.1:8200/noop> <rps> <seconds> <timeout_ms> <max_inflight> <output_prefix>");
    }
    let uri: Uri = args[2].parse().context("Invalid no-op URL")?;
    if uri.scheme_str() != Some("http")
        || uri.path() != "/noop"
        || !matches!(uri.host(), Some("127.0.0.1" | "localhost"))
    {
        bail!("No-op endpoint must be a loopback HTTP URL ending in /noop");
    }
    let rps: f64 = args[3].parse().context("Invalid RPS")?;
    schedule::scheduled_offset(0, rps)?;
    let seconds: f64 = args[4].parse().context("Invalid duration")?;
    if !seconds.is_finite() || seconds <= 0.0 || seconds > 30.0 {
        bail!("Duration must be >0 and <=30 seconds for guarded calibration");
    }
    let n_float = rps * seconds;
    if !n_float.is_finite() || n_float < 1.0 || n_float > 15000.0 {
        bail!("Calibration request count must be 1..15000");
    }
    let count = n_float.round() as usize;
    let timeout_ms: u64 = args[5].parse()?;
    if timeout_ms == 0 || timeout_ms > 10000 {
        bail!("Timeout must be 1..10000ms");
    }
    let max_inflight: usize = args[6].parse()?;
    if max_inflight == 0 || max_inflight > 1024 {
        bail!("max_inflight must be 1..1024");
    }
    let workers: usize = std::env::var("COMET_LOADGEN_WORKERS")
        .unwrap_or_else(|_| "2".into())
        .parse()?;
    if workers == 0 || workers > 32 {
        bail!("COMET_LOADGEN_WORKERS must be 1..32");
    }
    let prefix = Path::new(&args[7]);
    let jsonl = prefix.with_extension("requests.jsonl");
    let summary = prefix.with_extension("summary.json");
    if jsonl.exists() || summary.exists() {
        bail!("Refusing to overwrite calibration results");
    }
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(workers)
        .enable_all()
        .build()?;
    let client = http_client::HttpClient::new(Duration::from_millis(timeout_ms))?;
    let result = runtime.block_on(noop_dispatcher::dispatch(
        count,
        rps,
        uri,
        client,
        max_inflight,
    ))?;
    let mut file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&jsonl)?;
    for rec in &result.records {
        serde_json::to_writer(&mut file, rec)?;
        writeln!(file)?;
    }
    file.sync_all()?;
    let mut file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&summary)?;
    serde_json::to_writer_pretty(&mut file, &result.summary)?;
    file.sync_all()?;
    println!("NOOP CALIBRATION: {} requests, {} success, {} fail, {} timeout, {} dropped, achieved {:.2} success/s, P95 {:?} ms", result.summary.offered_requests, result.summary.successful_requests, result.summary.failed_requests, result.summary.timed_out_requests, result.summary.dropped_requests, result.summary.achieved_success_rps, result.summary.p95_latency_ms);
    println!("Summary: {}", summary.display());
    Ok(())
}

fn main() -> Result<()> {
    let args: Vec<String> = env::args().collect();
    if args.get(1).map(String::as_str) == Some("noop") {
        return run_noop_mode(&args);
    }

    if args.len() != 3 && !(args.len() == 10 && args[3] == "http") {
        bail!(
            "Usage: comet_v2_loadgen <trace.json> <golden.json>              [http <endpoint> <backend> <rps> <timeout_ms> <max_inflight> <output_prefix>]"
        );
    }

    let data =
        fs::read_to_string(&args[1]).with_context(|| format!("Cannot read trace: {}", args[1]))?;

    let trace: Trace = serde_json::from_str(&data).context("Invalid trace JSON")?;

    validate(&trace)?;
    verify_golden(&trace, &args[2])?;

    if args.len() == 10 {
        return run_http_mode(&trace, &args);
    }

    println!("PASS: COMET-Wasm V2 trace and golden provenance validated");
    println!("Schema: {}", trace.schema_version);
    println!("Model: {}", trace.model);
    println!("Dataset: {}", trace.dataset);
    println!("Seed: {}", trace.seed);
    println!("Requests: {}", trace.request_count);
    println!("Tenants: {}", trace.tenant_count);
    println!("Mode: validation only; no HTTP requests dispatched");

    println!("CLOCK-BASED DRY RUN (100 offered RPS)");

    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_time()
        .build()?;

    let arrivals = runtime.block_on(timing::dry_run(trace.request_count, 100.0))?;

    let max_delay_ns = arrivals.iter().map(|r| r.delay_ns).max().unwrap_or(0);

    let last = arrivals.last().context("No arrival records generated")?;

    println!("Scheduled arrivals: {}", arrivals.len());
    println!("Last sequence: {}", last.sequence);
    println!(
        "Last scheduled offset (ms): {:.3}",
        last.scheduled_ns as f64 / 1_000_000.0
    );
    println!(
        "Last actual offset (ms): {:.3}",
        last.actual_ns as f64 / 1_000_000.0
    );
    println!(
        "Maximum scheduling delay (ms): {:.3}",
        max_delay_ns as f64 / 1_000_000.0
    );
    println!("HTTP requests dispatched: 0");

    println!("DRY-RUN ARRIVAL SCHEDULE (100 offered RPS)");
    println!("sequence,tenant_slot,scheduled_offset_ms");

    for request in trace.requests.iter().take(5) {
        let offset = schedule::scheduled_offset(request.sequence, 100.0)?;
        println!(
            "{},{},{:.3}",
            request.sequence,
            request.tenant_slot,
            offset.as_secs_f64() * 1000.0
        );
    }

    let final_offset = schedule::scheduled_offset(trace.request_count - 1, 100.0)?;

    println!(
        "Last scheduled arrival: {:.3} ms",
        final_offset.as_secs_f64() * 1000.0
    );

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_empty_trace() {
        let trace = Trace {
            schema_version: "comet-v2-trace-v1".into(),
            model: "lr".into(),
            dataset: "iris_binary".into(),
            seed: 42,
            request_count: 0,
            tenant_count: 1,
            golden_model_sha256: "a".repeat(64),
            golden_dataset_sha256: "b".repeat(64),
            golden_artifact_sha256: "c".repeat(64),
            requests: vec![],
        };

        assert!(validate(&trace).is_err());
    }
}
